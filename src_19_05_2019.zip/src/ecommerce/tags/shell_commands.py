'''
#shell session 1
#python manage.py shell
'''

from tags.models import tags

qs = Tag.objects.all()
print(qs)
red = Tag.objects.last()
red.title
red.slug

red.products

red.products.all()

red.products.all().first()

exit()

from products.models import Product
qs = Product.objects.all()
print(qs)
tamota=qs.first()
tamota.title
tamota.description

tamota.tags
tamota.tag_set
tamota.tag_set.filter(title__icontains='black')
