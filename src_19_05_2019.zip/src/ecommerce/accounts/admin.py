from django.contrib import admin
from .models import GuestEmail
# Register your models here.

admin.site.register(GuestEmail)